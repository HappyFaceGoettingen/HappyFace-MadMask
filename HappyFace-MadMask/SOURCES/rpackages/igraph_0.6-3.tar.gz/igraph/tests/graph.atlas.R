
library(igraph) ; igraph.options(print.full=TRUE)

graph.atlas(124)
graph.atlas(234)

