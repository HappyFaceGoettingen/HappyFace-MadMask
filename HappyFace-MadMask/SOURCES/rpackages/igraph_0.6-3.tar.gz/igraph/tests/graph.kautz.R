
library(igraph) ; igraph.options(print.full=TRUE)

graph.kautz(2,3)

